# # Enter your code here. Read input from STDIN. Print output to STDOUT
# class Node:
#     def __init__(self, data):
#         self.data = data
#         self.last = None
#
#     def __str__(self):
#         return "{} <--".format(self.data)
#
#     def change_data(self, data):
#         self.data = data
#
#     def get_data(self):
#         return self.data
#
#     # def create_link(self, node):
#     #     self.last = node
#
#
# class Queue:
#     def __init__(self):
#         self.head = None
#         self.count = 0
#
#     # def __init__(self, head):
#     #     self.head = head
#
#     def __str__(self):
#         string = ""
#         current = self.head
#
#         # if empty
#         if self.is_empty() is True:
#             return "Empty"
#
#         while current is not None:
#             string += str(current)
#             current = current.last
#
#         return string
#
#     def is_empty(self):
#         if self.head is None:
#             return True
#         else:
#             return False
#
#     def enqueue(self, node):
#         if self.is_empty() is True:
#             self.head = node
#             self.count += 1
#         else:
#             current = self.head
#             self.head = node
#             self.head.last = current
#             self.count += 1
#
#             # node.create_link(self.head)
#             # while current is not None:
#             #     temp = current
#             #     current = current.last
#
#     def dequeue(self):
#         i = 0
#         current = self.head
#
#         # empty
#         if self.is_empty():
#             return None
#
#         # one element
#         elif self.count == 1:
#             deleted_element = self.head
#             self.head = None
#             self.count -= 1
#             return deleted_element
#
#         # two elements
#         elif self.count == 2:
#             deleted_element = self.head.last
#             self.head.last = None
#             self.count -= 1
#             return deleted_element
#
#         # greater than two elements
#         else:
#             # locate the first element placed in the queue
#             while i < self.count - 2:
#                 current = current.last
#                 i += 1
#
#             deleted_element = current.last
#             current.last = None
#             self.count -= 1
#
#             return deleted_element
#
#
# q = Queue()
# node1 = Node(14)
# node2 = Node(28)
# node3 = Node(44)
#
# q.enqueue(node1)
# print(q)
# q.enqueue(node2)
# print(q)
# q.enqueue(node3)
# print(q)
# q.dequeue()
# print(q)
# q.dequeue()
# print(q)
# q.dequeue()
# print(q)
# q.dequeue()
# print(q)
# Enter your code here. Read input from STDIN. Print output to STDOUT
class Node:
    def __init__(self, data):
        self.data = data
        self.last = None

    def __str__(self):
        return "{} ".format(self.data)

    def change_data(self, data):
        self.data = data

    def get_data(self):
        return self.data


class Queue:
    def __init__(self):
        self.head = None
        self.count = 0

    def __str__(self):
        string = ""
        current = self.head

        # if empty
        if self.is_empty() is True:
            return "Empty"

        while current is not None:
            string += str(current)
            current = current.last

        return string

    def get_head(self):
        print(self.head)

    def is_empty(self):
        if self.head is None:
            return True
        else:
            return False

    def enqueue_as_stack(self, node):
        node = Node(node)
        if self.is_empty() is True:
            self.head = node
            self.count += 1
        else:
            current = self.head
            self.head = node
            self.head.last = current
            self.count += 1

    def enqueue(self, node):
        node = Node(node)
        if self.is_empty() is True:
            self.head = node
            self.count += 1
        else:
            current = self.head
            self.head = node
            self.head.last = current
            self.count += 1

    def dequeue(self):
        i = 0
        current = self.head

        # empty
        if self.is_empty():
            return None

        # one element
        elif self.count == 1:
            deleted_element = self.head
            self.head = None
            self.count -= 1
            return deleted_element

        # two elements
        elif self.count == 2:
            deleted_element = self.head.last
            self.head.last = None
            self.count -= 1
            return deleted_element

        # greater than two elements
        else:
            # locate the first element placed in the queue
            while i < self.count - 2:
                current = current.last
                i += 1

            deleted_element = current.last
            current.last = None
            self.count -= 1

            return deleted_element


file = open("C:\\Users\\HP\\Documents\\AIoftheTiger New\\input.txt", 'r')
queries = int(file.readline())
# queries = int(input())
q = Queue()

for i in range(0, queries):

    decision = list(file.readline().split(" "))
    # decision = list(input().split(" "))

    if (int(decision[0]) == 1):
        q.enqueue(int(decision[1]))

    elif (int(decision[0]) == 2):
        q.dequeue()

    else:
        q.get_head()








